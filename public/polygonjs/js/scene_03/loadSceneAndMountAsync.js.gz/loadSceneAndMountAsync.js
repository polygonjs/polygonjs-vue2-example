import{a as c}from"./chunk-5TJDEEAE.js";import"./chunk-YGXD56TG.js";var r=async function(e={}){return e&&e.createViewer==null&&(e.createViewer=!0),c(e)};export{r as loadSceneAndMountAsync_scene_03};
