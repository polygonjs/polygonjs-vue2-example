import{a as c}from"./chunk-DP54FT3M.js";import"./chunk-Y4M4RIKR.js";var r=async function(e={}){return e&&e.createViewer==null&&(e.createViewer=!0),c(e)};export{r as loadSceneAndMountAsync_scene_02};
